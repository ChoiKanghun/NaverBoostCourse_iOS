//
//  PostButtonTableViewCell.swift
//  BoxOfficeBoostCourseAssignmentNumberFive
//
//  Created by 최강훈 on 2020/12/15.
//  Copyright © 2020 최강훈. All rights reserved.
//

import UIKit

class PostButtonTableViewCell: UITableViewCell {

    @IBOutlet weak var postCommentButton: UIButton!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
