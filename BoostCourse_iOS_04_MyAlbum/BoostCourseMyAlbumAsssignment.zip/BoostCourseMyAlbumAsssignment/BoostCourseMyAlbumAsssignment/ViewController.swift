//
//  ViewController.swift
//  BoostCourseMyAlbumAsssignment
//
//  Created by 최강훈 on 2020/11/02.
//  Copyright © 2020 최강훈. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

