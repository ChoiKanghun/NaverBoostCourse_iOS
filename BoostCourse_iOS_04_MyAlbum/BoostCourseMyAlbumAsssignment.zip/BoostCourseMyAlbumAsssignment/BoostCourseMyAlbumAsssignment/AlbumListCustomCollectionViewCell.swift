//
//  AlbumListCustomCollectionViewCell.swift
//  BoostCourseMyAlbumAsssignment
//
//  Created by 최강훈 on 2020/11/02.
//  Copyright © 2020 최강훈. All rights reserved.
//

import UIKit

class AlbumListCustomCollectionViewCell: UICollectionViewCell {
    @IBOutlet weak var representativeImageView: UIImageView!
    @IBOutlet weak var albumNameLabel: UILabel!
    @IBOutlet weak var countOfPicturesInAlbumLabel: UILabel!
    
}
